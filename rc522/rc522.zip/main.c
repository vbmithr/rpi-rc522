/*
 * main.c
 *
 *  Created on: 14.08.2013
 *      Author: alexs
 */
#include <stdio.h>
#include <string.h>
#include "bcm2835.h"
#include "rc522.h"

uint8_t NFC_init();

int main() {

	uint8_t buff[MAXRLEN];
	uint8_t SN[7];

	char status,tmp;
	//	char *r_desc[0x3c]={"Reserved","CommandReg","ComlEnReg","DivlEnReg","ComIrqReg","DivIrqReg","ErrorReg","Status1Reg","Status2Reg","FIFODataReg","FIFOLevelReg","WaterLevelReg","ControlReg","BitFramingReg","CollReg","Reserved","Reserved","ModeReg","TxModeReg","RxModeReg","TxControlReg","TxASKReg","TxSelReg","RxSelReg","RxThresholdReg","DemodReg","Reserved","Reserved","MfTxReg","MfRxReg","Reserved","SerialSpeedReg","Reserved","CRCResultRegMSB","CRCResultRegLSB","Reserved","ModWidthReg","Reserved","RFCfgReg","GsNReg","CWGsPReg","ModGsPReg","TModeReg","TPrescalerReg","TReloadRegHi","TReloadRegLo","TCounterValRegHi","TCounterValRegLo","Reserved","TestSel1Reg","TestSel2Reg","TestPinEnReg","TestPinValueReg","TestBusReg","AutoTestReg","VersionReg","AnalogTestReg","TestDAC1Reg","TestDAC2Reg","TestADCReg"};

	if (NFC_init()) return 1; // Если не удалось инициализировать RC522 выходим.

	for (;;) {
		tmp=PcdRequest(PICC_REQIDL,buff);
		if (tmp==MI_OK) {
			status=PcdAnticoll(PICC_ANTICOLL1,buff);
			if (status==MI_OK) {
				printf("Card sn1 -> 0x%02x%02x%02x%02x\n",buff[0],buff[1],buff[2],buff[3]);
				if (buff[0]==0x88) {
					memcpy(SN,&buff[1],3);
					status=PcdSelect(PICC_ANTICOLL1,buff);
					status=PcdAnticoll(PICC_ANTICOLL2,buff);
					if (status==MI_OK) {
						memcpy(&SN[3],buff,4);
						printf("SN -> 0x");
						for (tmp=0;tmp<7;tmp++) printf("%02x",SN[tmp]);
						printf("\n");
						status=PcdSelect(PICC_ANTICOLL2,buff);
						PcdRead(0,buff);
						for (tmp=0;tmp<16;tmp++) {
							printf("%02x",buff[tmp]);
							if (((tmp+1) % 4)==0) printf(" ");
						}
						printf("\n");

						PcdRead(4,buff);
						for (tmp=0;tmp<16;tmp++) {
							printf("%02x",buff[tmp]);
							if (((tmp+1) % 4)==0) printf(" ");
						}
						printf("\n");

						PcdRead(8,buff);
						for (tmp=0;tmp<16;tmp++) {
							printf("%02x",buff[tmp]);
							if (((tmp+1) % 4)==0) printf(" ");
						}
						printf("\n");

						PcdRead(0x0c,buff);
						for (tmp=0;tmp<16;tmp++) {
							printf("%02x",buff[tmp]);
							if (((tmp+1) % 4)==0) printf(" ");
							buff[tmp]=0;
						}
						printf("\n");
//						buff[0]=7;
//						buff[1]=4;
//						buff[2]=8;
//						buff[3]=4;

//						if (SN[0]==0x34) {PcdWrite(0x13,buff);}
//						else {PcdWrite(0x04,buff);
//						PcdWrite(0x05,buff);
//						PcdWrite(0x06,buff);
//						PcdWrite(0x07,buff);
//						PcdWrite(0x0c,buff);
//						PcdWrite(0x0d,buff);
//						PcdWrite(0x0e,buff);
//						PcdWrite(0x0f,buff);}

						PcdHalt();
					}
				}
			}
		}else{ }
	}

	bcm2835_spi_end();
	bcm2835_close();
	return 0;

}


uint8_t NFC_init() {
	if (!bcm2835_init()) {
		perror("Can't init bcm2835!\n");
		return 1;
	}
	bcm2835_spi_begin();
	bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);      // The default
	bcm2835_spi_setDataMode(BCM2835_SPI_MODE0);                   // The default
	bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_32); // The default
	bcm2835_spi_chipSelect(BCM2835_SPI_CS0);                      // The default
	bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);      // the default
	InitRc522();
	return 0;
}

